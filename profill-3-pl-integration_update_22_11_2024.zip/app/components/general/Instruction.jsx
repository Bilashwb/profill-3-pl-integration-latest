export default function Instruction() {
  return (
    <div>Instruction</div>
  )
}
